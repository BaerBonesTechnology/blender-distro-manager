# UTF-8 fixture: café
